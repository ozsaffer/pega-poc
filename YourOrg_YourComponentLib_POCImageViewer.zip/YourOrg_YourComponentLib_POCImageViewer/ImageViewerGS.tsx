import React, {useEffect, useRef, useState, MouseEvent } from 'react';

// import StyledYourOrgYourComponentLibPocImageViewerWrapper from './styles';
import {createStyles, makeStyles, Theme} from "@material-ui/core/styles";
import Button from "@mui/material/Button";
import Modal from "@mui/material/Modal";
import {Box} from "@mui/material";
import Typography from "@mui/material/Typography";

import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import ZoomInIcon from '@mui/icons-material/ZoomIn';


const data = {
    designIndex: 1,
    imageIndex: 1,
    extractDesigns: true,
    navigateDesigns: true,
    designs: [
        { id:"R10773657", src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.JPG", srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.THUMB.JPG", srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.MEDIUM.JPG"},
        { id:"R10773661", src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG", srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.THUMB.JPG", srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.MEDIUM.JPG"},
        { id:"R10773663", src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773663/1.0/R10773663.JPG", srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773663/1.0/R10773663.THUMB.JPG", srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773663/1.0/R10773663.MEDIUM.JPG"},
        { id:"R10773665", src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773665/1.0/R10773665.JPG", srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773665/1.0/R10773665.THUMB.JPG", srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773665/1.0/R10773665.MEDIUM.JPG"},
        { id:"R10773666", src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773666/1.0/R10773666.JPG", srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773666/1.0/R10773666.THUMB.JPG", srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773666/1.0/R10773666.MEDIUM.JPG"},
        { id:"R10773667", src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773667/1.0/R10773667.JPG", srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773667/1.0/R10773667.THUMB.JPG", srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773667/1.0/R10773667.MEDIUM.JPG"},
        { id:"R10773668", src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773668/1.0/R10773668.JPG", srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773668/1.0/R10773668.THUMB.JPG", srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773668/1.0/R10773668.MEDIUM.JPG"}

        /*
          id: string;
  images?: DesignImage[];
  status: string;
  product?: string[];
  processingStatus?: string;
  registrationNumber?: string;
  registrationOfficeCode?: string;
  classifications?: string[];
  priorityDate?: string;
  filedDate?: string;
  renewalDueDate?: string;
  applicants?: string[];
  representatives?: string[];
  designers?: string[];
  awaitingExam?: boolean;
  awaitingFormalities?: boolean;
  inGracePeriod?: boolean;
  underExam?: boolean;
  underFormalities?: boolean;
  opi?: boolean;
        
         */
        
    ]
}

export default function ImageViewerGS(childrend) {

    const mobileMode = false
    
    const rotations = [0, 90, 180, 270] as const;
    type Rotation = typeof rotations[number];

    const zoomSize = 400;
    const zoomScales = [0, 2, 4] as const;
    type ZoomScale = typeof zoomScales[number];


    // const hoveringIndex: number | null = null;
    const [hoveringIndex, setHoveringIndex] = useState<number | null>(null);
    const [imageContainerRect, setImageContainerRect] = useState<{width: number, height: number, top: number, left: number} | null | DOMRect>(null);
    const [imageNaturalSize, setImageNaturalSize] = useState< {width: number, height: number} | null>(null);
    const [imageRect, setImageRect] = useState< {width: number, height: number, top: number, left: number, scale: number} | null>(null);
    
    // imageRotation: Rotation = 0;
    const [imageRotation, setImageRotation] = useState<Rotation>(0);
    
    // imageZoomScale: ZoomScale = zoomScales[0];
    const [imageZoomScale, setImageZoomScale] = useState<ZoomScale>(zoomScales[1]);
    const [showImageZoom, setShowImageZoom] = useState<boolean>(false);
    

    const useStyles = makeStyles((theme: Theme) =>
        createStyles(
    {
        designPopupHeader: {
            width: "100%",
            display: "flex",
            alignItems: "top"
        },
        title: {
            width: "50%",
            flex: "1 auto",
            fontSize: "1rem",
            margin: "0",
            padding: "0",
            "fontWeightAbsolute": "600",
        },
        "design_popup_header__title_a": {
        "color": "'green'",
            "textDecoration": "none"
    },
        "design_popup_header__title_a_svg": {
        "fontSize": "0.8rem",
            "marginBottom": "0.15rem"
    },
        "design_popup_header__title_a_hover": {
        "textDecoration": "underline"
    },
        headerButtons: {
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            width: "50%",
            marginRight: "0.5rem"
        },
        "design_popup_header__header_buttons_button_first_of_type": {
        "marginRight": "0.5rem"
    },
        "design_popup_header__header_buttons_span": {
        "flex": "0 auto !important",
            "margin": "0 0.3em"
    },
        "design_popup_content": {
        "display": "flex",
            "position": "relative",
            "width": "100%",
            "height": "100%",
            "background": "white"
    },
        "design_popup_content__prev_image_btn": {
        "flex": "auto 0",
            "border": "none",
            "borderRadius": "50%",
            "fontSize": "1.2rem",
            "boxShadow": "0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)"
    },
        "design_popup_content__next_image_btn": {
        "flex": "auto 0",
            "border": "none",
            "borderRadius": "50%",
            "fontSize": "1.2rem",
            "boxShadow": "0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)"
    },
        "design_popup_content__prev_image_btn_focus": {
        "outline": "auto"
    },
        "design_popup_content__next_image_btn_focus": {
        "outline": "auto"
    },
        "design_popup_content__controls": {
        "flex": "auto 0",
            "width": "8rem",
            "height": "100%",
            "padding": "4rem 0",
            "boxSizing": "border-box",
            "background": "'$sidebarBg'",
            "overflow": "auto"
    },
        "design_popup_content__controls__thumbs": {
        "width": "5rem",
            "margin": "0 auto",
            "padding": "0",  
            "textAlign": "center",
            "listStyleType": "none",
            backgroundColor: "red",
            alignItems: "flex-start"
            
    },
        "design_popup_content__controls__thumbs__thumb": {
        "position": "relative",
            "width": "100%",
            "marginBottom": "0.5rem",
            "borderRadius": "3px",
            "background": "#fff",
            "boxShadow": "0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)",
            "cursor": "pointer",
            "transition": "all 0.3s ease"
    },
        "design_popup_content__controls__thumbs__thumb_button": {
        "width": "100%",
            "height": "auto",
            "boxShadow": "none",
            "border": "0",
            "margin": "0",
            "padding": "0"
    },
        "design_popup_content__controls__thumbs__thumb_button_focus": {
        "outline": "auto"
    },
        "design_popup_content__controls__thumbs__thumb_img": {
        "borderRadius": "3px",
            "display": "block",
            "height": "auto",
            "objectFit": "scale-down",
            "width": "100%"
    },
        "design_popup_content__controls__thumbs__thumb_selected__after": {
        "background": "'$externalPrimary'",
            "bottom": "0",
            "content": "\"\"",
            "height": "4px",
            "left": "0",
            "position": "absolute",
            "width": "100%",
            "borderRadius": "0 0 3px 3px"
    },
        "design_popup_content__controls__thumbs__thumb_last_child": {
        "marginBottom": "0"
    },
        "design_popup_content__design_image_container": {
        "flex": "1 auto",
            "position": "relative",
            // "width": "calc(100% - 140px)",
            // TODO: fix
            "width": "640px",
            "height": "100%",
            "overflow": "hidden",
            "cursor": "zoom-in"
    },
        "design_popup_content__design_image_container_img": {
        "position": "absolute",
            "top": "0",
            "left": "0",
            "transformOrigin": "top left"
    },
        "design_popup_content__design_image_container__design_image_zoom": {
        "position": "absolute",
            "borderRadius": "50%",
            "boxSizing": "border-box",
            "backgroundColor": "white",
            "backgroundRepeat": "no-repeat"
    },
        "design_popup_content__design_image_container__design_image_zoom__before": {
        "boxShadow": "0 0 5px 1px rgba(0, 0, 0, 0.5)"
    },
        "design_popup_content__design_image_container__design_image_zoom__after": {
        "boxShadow": "inset 0 0 5px 1px rgba(0, 0, 0, 0.5)"
    },
        "design_popup_content__design_image_container__image_controls": {
        "display": "flex",
            "alignItems": "center",
            "justifyContent": "space-between",
            "position": "absolute",
            "top": "0",
            "left": "calc(50% - 4rem)",
            "width": "8rem",
            "padding": "0.5rem",
            "borderRadius": "0 0 3px 3px",
            "boxSizing": "border-box",
            "background": "rgba(255, 255, 255, 0.5)",
            "boxShadow": "0 0 2px rgba(0, 0, 0, 0.26)"
    },
        "design_popup_content__design_image_container__image_controls_button": {
        "flex": "auto 0",
            "width": "1.5rem",
            "height": "1.5rem",
            "padding": "0",
            "borderRadius": "50%",
            "background": "white",
            "color": "'$externalPrimary'",
            "fontSize": "0.8rem",
            "cursor": "pointer"
    },
        "design_popup_content__design_image_container__image_controls__button": {
        "flex": "auto 0",
            "width": "1.5rem",
            "height": "1.5rem",
            "padding": "0",
            "borderRadius": "50%",
            "background": "white",
            "color": "'$externalPrimary'",
            "fontSize": "0.8rem",
            "cursor": "pointer"
    },
        "design_popup_content__design_image_container__image_controls_button_half": {
        "background": "\"linear-gradient(lighten('$externalPrimary', 30%) 50%, '$externalPrimary' 50%)\"",
            "color": "white"
    },
        "design_popup_content__design_image_container__image_controls__button_half": {
        "background": "\"linear-gradient(lighten('$externalPrimary', 30%) 50%, '$externalPrimary' 50%)\"",
            "color": "white"
    },
        "design_popup_content__design_image_container__image_controls_button_fill": {
        "background": "'$externalPrimary'",
            "color": "white"
    },
        "design_popup_content__design_image_container__image_controls__button_fill": {
        "background": "'$externalPrimary'",
            "color": "white"
    },
        "mobile_mode___v_deep__content": {
        "width": "100vw",
            "height": "100vh",
            "maxWidth": "100vw",
            "maxHeight": "100vh"
    },
        "mobile_mode__design_popup_header__title": {
        "width": "100%"
    },
        "mobile_mode__design_popup_header__header_buttons": {
        "display": "none"
    },
        "mobile_mode__design_popup_content": {
        "flexDirection": "column-reverse"
    },
        "mobile_mode__design_popup_content__prev_image_btn": {
        "left": "10px"
    },
        "mobile_mode__design_popup_content__next_image_btn": {
        "right": "10px"
    },
        "mobile_mode__design_popup_content__controls": {
        "display": "flex",
            "alignItems": "center",
            "width": "100%",
            "height": "7rem",
            "padding": "0 4rem"
    },
        "mobile_mode__design_popup_content__controls__thumbs": {
        "width": "max-content",
            "height": "5rem",
            "margin": "0",
            "whiteSpace": "nowrap"
    },
        "mobile_mode__design_popup_content__controls__thumbs__thumb": {
        "display": "inline-block",
            "maxWidth": "none",
            "width": "auto",
            "height": "100%",
            "marginBottom": "0",
            "marginRight": "0.5rem"
    },
        "mobile_mode__design_popup_content__controls__thumbs__thumb_button": {
        "width": "auto",
            "height": "100%",
            "boxShadow": "none"
    },
        "mobile_mode__design_popup_content__controls__thumbs__thumb_img": {
        "width": "auto",
            "height": "100%"
    },
        "mobile_mode__design_popup_content__controls__thumbs__thumb_last_child": {
        "marginRight": "4rem"
    },
        "mobile_mode__design_popup_content__design_image_container": {
        "width": "auto",
            "height": "calc(100% - 140px)",
            "cursor": "default"
    }
    })
    );
    const classes = useStyles();

    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);



    const designImage = useRef<HTMLImageElement>(null);
    const designImageContainer = useRef(null);
    function updateLayout() {
        // const designImageContainer = $refs.designImageContainer as HTMLElement;
        // const designImage = $refs.designImage as HTMLImageElement;
        if (!designImageContainer.current || !designImage.current) {
            setImageContainerRect(null);
            setImageNaturalSize(null);
            setImageRect(null);
            return;
        }
        
        const designImageContainerLocal = designImageContainer.current.getBoundingClientRect()
        setImageContainerRect(designImageContainer.current.getBoundingClientRect());
                

        setImageNaturalSize({
            width: designImage.current.naturalWidth,
            height: designImage.current.naturalHeight
        });

        // rotated dimensions
        const rotate = rotations.indexOf(imageRotation);
        const swapDims = (Math.abs(rotate % 2) === 1);
        const containerRotatedWidth = (swapDims ? designImageContainerLocal.height : designImageContainerLocal.width);
        const containerRotatedHeight = (swapDims ? designImageContainerLocal.width : designImageContainerLocal.height);

        // image aspect ratio scaled down if needed
        const wScale = Math.min(containerRotatedWidth / designImage.current.width, 1);
        const hScale = Math.min(containerRotatedHeight / designImage.current.height, 1);
        const scale = Math.min(wScale, hScale);

        // scaled dimentions and position
        const width = designImage.current.width * scale;
        const height = designImage.current.height * scale;
        const rotatedWidth = (swapDims ? height : width);
        const rotatedHeight = (swapDims ? width : height);
        setImageRect({
            width,
            height,
            top: (designImageContainerLocal.height - rotatedHeight) / 2,
            left: (designImageContainerLocal.width - rotatedWidth) / 2,
            scale
        });
    }

    const thumbsDiv = useRef<Array<HTMLElement>>(null);
    function scrollActiveThumbIntoView(index: number) {
        // const thumbs = $refs.thumbs as HTMLElement[];
        if (thumbsDiv.current && index >= 0 && index < thumbsDiv.current.length) {
            thumbsDiv.current[index].scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });
        }
    }


    
    
    



    function isExtracted(): boolean {
        // return !!store.extracts.extract(design.id);
        return true
    }

    // function design(): DesignResult {
    function design() {
        // return data.designs[data.designIndex];
        return data.designs[0];
    }

    function designIndex(): number {
        return data.designIndex;
    }

    function imageIndex(): number {
        return data.imageIndex;
    }

    function imageUrl(): string {
        if (!design.images || design.images.length === 0) {
            return '';
        }

        const index = ((typeof hoveringIndex === 'number' ? hoveringIndex : imageIndex) || 0);
        // TODO: const i = design.images[index];
        const i = design.images[0];
        // return Utils.imageUrl(design.id, i);
        return i.src
    }

    // function imageStyle(): Partial<CSSStyleDeclaration> {
    function imageStyle() {
        if (!imageRect) {
            return {};
        }

    let top = imageRect.top;
    let left = imageRect.left;
    switch (imageRotation) {
        case 90:
            left += imageRect.height;
            break;
        case 180:
            top += imageRect.height;
            left += imageRect.width;
            break;
        case 270:
            top += imageRect.width;
            break;
        default:
            break
    }

    return {
        top: `${top}px`,
        left: `${left}px`,
        width: `${imageRect.width}px`,
        height: `${imageRect.height}px`,
        transform: `rotate(${imageRotation}deg)`
    };
}

    function thumbs(): string[] {
        if (!design.images) {
            return [];
        }

        // return design.images.map(x => Utils.imageUrl(design.id, x, 'THUMB'));
        return design.images.map(x => x.src);
    }

    function imageZoomScaleIndex(): number {
        return zoomScales.indexOf(imageZoomScale);
    }

    function imageZoomScaleTooltip(): string {
        let index = zoomScales.indexOf(imageZoomScale) + 1;
        if (index > zoomScales.length - 1) {
            index = 0;
        }

        if (index === 0) {
            return `Turn off zoom`;
        }

        return `Zoom ${zoomScales[index]}x on hover`;
    }

    function fullSizeImageLink(): string {
        if (!design.images) {
            return '';
        }

        // return `${WindowData.baseUrl}/search/details/${design.id}/representation/?i=${design.images[imageIndex].i}&v=${design.images[imageIndex].v}`;
        return design.images[imageIndex].src;
    }

/*    @Emit()
    toggleExtract(result: DesignResult, toggle: boolean) {
    }

    @Emit()
    showImage(designIndex: number, imageIndex: number) {
    }

    @Emit()
    close() {
    } */

    function rotate(rotation: 'left' | 'right' | 'clear') {
        let index = rotations.indexOf(imageRotation);
        switch (rotation) {
            case 'left':
                index = (index > 0 ? index - 1 : rotations.length - 1);
                break;
            case 'right':
                index = (index < rotations.length - 1 ? index + 1 : 0);
                break;
            default:
                index = 0;
                break;
        }

        setImageRotation(rotations[index]);
        updateLayout();
    }



    function openFullSize() {
        window.open(fullSizeImageLink, '_blank');
    }


    const designImageZoom = useRef(null);

 /*   const handleMouseEvent = (e: MouseEvent<HTMLButtonElement>) => {
        
        // Do something
    }; */
    
    const handleZoom = (event: MouseEvent<HTMLDivElement>) => {
        
        event.preventDefault();
        if (mobileMode) {
            return;
        }

        /// const designImageZoom = $refs.designImageZoom as HTMLElement;

        if (!imageContainerRect || !imageNaturalSize || !imageRect || !imageZoomScale || !designImageZoom || !event) {
            setShowImageZoom(false);
            return;
        }
        // zoom position and size
        const rotate = rotations.indexOf(imageRotation);
        designImageZoom.current.style.top = `${event.clientY - imageContainerRect.top - zoomSize / 2}px`;
        designImageZoom.current.style.left = `${event.clientX - imageContainerRect.left - zoomSize / 2}px`;
        designImageZoom.current.style.width = `${zoomSize}px`;
        designImageZoom.current.style.height = `${zoomSize}px`;
        designImageZoom.current.style.transform = `rotate(${rotate * 90}deg)`;

        // zoom background
        const swapDims = (Math.abs(rotate % 2) === 1);
        const rotatedImageRect = {
            ...imageRect,
            width: (swapDims ? imageRect.height : imageRect.width),
            height: (swapDims ? imageRect.width : imageRect.height)
        };

        const invertX = (rotate === 1 || rotate === 2);
        const invertY = (rotate === 2 || rotate === 3);
        const imageX = (invertX ? rotatedImageRect.width : 0) + (invertX ? -1 : 1) * (event.clientX - imageContainerRect.left - rotatedImageRect.left);
        const imageY = (invertY ? rotatedImageRect.height : 0) + (invertY ? -1 : 1) * (event.clientY - imageContainerRect.top - rotatedImageRect.top);
        const rotatedImageX = (swapDims ? imageY : imageX);
        const rotatedImageY = (swapDims ? imageX : imageY);
        const bgScale = imageZoomScale * imageRect.scale;
        // designImageZoom.current.style.backgroundImage = `url(${imageUrl})`;
        designImageZoom.current.style.backgroundImage = `url(${data.designs[0].src})`;
        designImageZoom.current.style.backgroundSize = `${imageNaturalSize.width * bgScale}px ${imageNaturalSize.height * bgScale}px`;
        designImageZoom.current.style.backgroundPosition = `${-rotatedImageX * imageZoomScale + zoomSize / 2}px ${-rotatedImageY * imageZoomScale + zoomSize / 2}px`;
        
        setShowImageZoom(true);
    }

    const nextZoom = (event) => {
        if (mobileMode) {
            return;
        }

        let index = zoomScales.indexOf(imageZoomScale) + 1;
        if (index > zoomScales.length - 1) {
            index = 0;
        }

        setImageZoomScale(zoomScales[index]);
        handleZoom(event); // zoom(event);
    }

    function prevImage() {
        doShowImage(designIndex, imageIndex - 1, 'prev');
    }

    function nextImage() {
        doShowImage(designIndex, imageIndex + 1, 'next');
    }

    function prevDesign() {
        doShowImage(designIndex - 1, 0);
    }

    function nextDesign() {
        doShowImage(designIndex + 1, 0);
    }

    function showDetails() {
        const query = $route.query;
        if ($route.name === 'extracts') {
            query.x = '1';
        }

        $router.push({
            name: 'details',
            params: {applicationNumber: design.id},
            query
        });

        close();
    }

    function doShowImage(designIndex: number, imageIndex: number, imageDirection?: string) {
        rotate('clear');

        // TODO thumb into view if necessary??

        // loop thru previews if we're not going thru designs
        if (!data.navigateDesigns && imageDirection && data.designs[designIndex].images) {
            if (imageDirection === 'next') {
                if (data.designs[designIndex].images!.length === imageIndex) {
                    imageIndex = 0;
                }
            } else {
                if (imageIndex === -1) {
                    imageIndex = data.designs[designIndex].images!.length - 1;
                }
            }
        }

        if (designIndex !== designIndex) {
            // skip designs with no images
            const delta = (designIndex < designIndex ? -1 : 1);
            while (
                designIndex >= 0 && designIndex < data.designs.length && !hasImages(designIndex)) {
                designIndex += delta;
            }

            if (designIndex < 0 || designIndex > data.designs.length - 1) {
                designIndex = designIndex;
                imageIndex = imageIndex;
            }
        }

        if (imageIndex !== imageIndex) {
            const design = data.designs[designIndex];
            imageIndex = Math.max(0, imageIndex);
            imageIndex = Math.min((design.images ? design.images.length - 1 : 0), imageIndex);
        }

        showImage(designIndex, imageIndex);
        scrollActiveThumbIntoView(imageIndex);
    }

    function hasImages(designIndex: number): boolean {
        return (!!data.designs[designIndex].images && data.designs[designIndex].images!.length > 0);
    }

    


    function keydown(e: Event) {
        switch ((e as KeyboardEvent).key) {
            case 'ArrowRight':
                e.stopPropagation();
                e.preventDefault();
                nextDesign();
                break;
            case 'ArrowLeft':
                e.stopPropagation();
                e.preventDefault();
                prevDesign();
                break;
            case 'ArrowUp':
                e.stopPropagation();
                e.preventDefault();
                prevImage();
                break;
            case 'ArrowDown':
                e.stopPropagation();
                e.preventDefault();
                nextImage();
                break;
            case 'r':
                if (!(e as KeyboardEvent).ctrlKey) {
                    e.stopPropagation();
                    e.preventDefault();
                    rotate('right');
                }
                break;
            default:
                break;
        }
    }
     

    useEffect(() => {
        window.addEventListener('keydown', keydown);
        window.addEventListener('resize', updateLayout);

        // const designImage = $refs.designImage as HTMLImageElement;
        if(designImage.current) {
            designImage.current.onload = updateLayout;
        }

        window.setTimeout(() => scrollActiveThumbIntoView(imageIndex), 100);

        return () => {
            window.removeEventListener('keydown', keydown);
            window.removeEventListener('resize', updateLayout);
        };


    }, []);



    const style2 = {
        position: 'absolute' as 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 1600,
        height: 600,
        bgcolor: 'background.paper',
        border: '2px solid #000',
        boxShadow: 24,
        p: 1,
        
        display: "flex",

        /*  
        position: "relative",
        width: "100%",
        height: "100%",
        background: "white" */
        
        
    };
    
    return (
        <>
            <Button onClick={handleOpen}>View all images</Button>
            <Modal 
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                
            >
                <Box sx={style2}>
                <>
                <div id={'header'} className={classes.designPopupHeader}>
                <div className={classes.designPopupHeader}>
                    <h2 className={classes.title} id="dialog-label">
                        Representations of
                        {/* <a href="#" @click.stop.prevent="showDetails()"> */}
                        {design.id}
                        {/* <uik-icon :icon="['fas', 'external-link-alt']"></uik-icon> */}
                        {/* </a> */}
            </h2>

            <div className={classes.headerButtons}>
               {/* <button v-if="!mobileMode && data.extractDesigns"
                        class="extract primary toggle square"
                :class="{fill: isExtracted}"
                :title="isExtracted ? 'Remove from my list' : 'Add to my list'"
                @click.stop.prevent="toggleExtract(design, !isExtracted)">
                <uik-icon :icon="['fas', 'flag']"/>
            </button>
 */ }
              {/* v-if="!mobileMode && data.navigateDesigns"
                    class="primary square" */}
                <Button 
            onClick={() => {prevDesign()}}> 
            {/* <uik-icon :icon="['fas', 'angle-left']"/> */}
            <KeyboardArrowLeftIcon/>;
        </Button> 

    {/* <span>Result {{data.designIndex + 1}} of {{data.designs.length}}</span> */}
     <span>Result 1 of {data.designs.length}</span> 

{/*    <button v-if="!mobileMode && data.navigateDesigns"
            class="primary square"
                            @click.stop.prevent="nextDesign()">
        <uik-icon :icon="['fas', 'angle-right']"/>
        </button> */}
                <Button
                    onClick={() => {nextDesign()}}>
                    {/* <uik-icon :icon="['fas', 'angle-left']"/> */}
                    <KeyboardArrowRightIcon/>;
                </Button>

            </div>
</div>
</div>


                {/* <template #content v-if="data"> */}
                <div>
                                        
                <div className={classes.design_popup_content}>
                    {/* <Button className={classes.design_popup_content__prev_image_btn} // primary icon no-fill prev-image-btn */}
                     <Button  // primary icon no-fill prev-image-btn
                    onClick={() => prevImage()}>
                    {/* <uik-icon :icon="['fas', 'chevron-up']" :rotation="(mobileMode ? 270 : null)"/> */}
                    <ExpandLessIcon/> 
                </Button> 
                    

                        <div className={classes.design_popup_content__controls}>
                    <ol className={classes.design_popup_content__controls__thumbs}>

                        {data.designs.map((designImage, thumbIndex) => 
                            <li 
                                key={designImage.id}
                                className={classes.design_popup_content__controls__thumbs__thumb}
                            >
                                <img src={designImage.srcThumb} alt={`Representation #${  thumbIndex + 1}`}/>
                            </li>
                        
                        )}

                        {thumbs().map((thumb, thumbIndex) =>
                            <li
                                    ref={thumbsDiv}
                                    key="thumbIndex"
                                    className={classes.design_popup_content__controls__thumbs__thumb}
                                    /* :class="{selected: thumbIndex === imageIndex}"
                                    onClick={doShowImage(designIndex, thumbIndex)} */>
{/*
                                    <button :aria-current="thumbIndex === imageIndex">
*/}
                                    <button type="button">
                                            <img src={thumb}/>
                                    </button>
                                </li>
                            )}
                        
                        
            </ol>
        </div>

{/*    <button class="primary icon no-fill next-image-btn"
                        @click="nextImage()">
        <uik-icon :icon="['fas', 'chevron-down']" :rotation="(mobileMode ? 270 : null)"/>
        </button> */}
                    <Button  // primary icon no-fill prev-image-btn
                        onClick={() => nextImage()}> 
                        {/* <uik-icon :icon="['fas', 'chevron-up']" :rotation="(mobileMode ? 270 : null)"/> */}
                        <ExpandMoreIcon/> 
                    </Button>



                   {/* className=classes.design_popup_content__design_image_container */}
                    <div className={classes.design_popup_content__design_image_container} // "design-image-container"
          ref={designImageContainer} onMouseMove={handleZoom} onClick={nextZoom}>                
                     {/* @mousemove="zoom($event)"
@mouseleave="zoom(null)"
@click="nextZoom($event)" */} 
        
      {/* <img ref={designImage} src={imageUrl()} style={imageStyle()}/> */}
       <img ref={designImage} src={data.designs[0].srcMedium} style={imageStyle()}/>
{/* alt="'Representation #' + (imageIndex + 1)"/> */}

        <div v-show="showImageZoom"
    className={classes.design_popup_content__design_image_container__design_image_zoom} // ="design-image-zoom"
     ref={designImageZoom} /> zoom
        </div>

    <ul className={classes.design_popup_content__design_image_container__image_controls}>
        <li>
            {/* <button class="primary no-fill rotate-left has-tooltip2" */}
            <button type="button" onClick={() => rotate('left')}>
            {/* <uik-icon :icon="['fas', 'undo']"></uik-icon> */}
        {/* <span className="tooltip2">Rotate left</span> */}
        <span>Rotate left</span>
    </button> 
</li>

    <li>
        {/* <button class="primary no-fill rotate-right has-tooltip2"
        @click.stop="rotate('right')">
        <uik-icon :icon="['fas', 'redo']"></uik-icon>
    <span class="tooltip2">Rotate right</span>
</button> */}
</li>

    <li v-if="!mobileMode">
        {/* class="primary zoom has-tooltip2" 
        :class="imageZoomScaleIndex < 1 ? 'no-fill' : imageZoomScaleIndex < 2 ? 'half' : 'fill'"
        @keydown.enter.space.stop.prevent="openFullSize()"
        @click.stop="nextZoom($event)" */}
        <Button onClick={nextZoom}> 

                    <ZoomInIcon/>
                {/* <uik-icon :icon="['fas', 'search-plus']"></uik-icon> */}
           {/* <span class="tooltip2">{{imageZoomScaleTooltip}}</span> */}
            <span>tip</span>
        </Button> 
</li>

    <li>{/*
        <a class"button primary full-size has-tooltip2"
        :href="fullSizeImageLink"
        target="_blank"
        tabindex="0"
        @click.stop>
        <uik-icon :icon="['fas', 'external-link-alt']"></uik-icon>
    <span class="tooltip2">Full size</span>
</a> */}
</li>
</ul>
</div>
</div>
           
                
                
                </>
                </Box>
            </Modal>
        </>
   
    );
};
