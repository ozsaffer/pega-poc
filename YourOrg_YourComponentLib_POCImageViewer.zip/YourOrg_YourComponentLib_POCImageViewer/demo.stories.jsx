import {withKnobs} from '@storybook/addon-knobs';

// import YourOrgYourComponentLibPocImageViewer from './index.tsx';
import ImageViewerGS from './ImageViewerGrid'


import configProps from './mock.stories';

export default {
    title: 'YourOrgYourComponentLibPocImageViewer',
    decorators: [withKnobs],
    // component: YourOrgYourComponentLibPocImageViewer
    component: ImageViewerGS
};

export const baseYourOrgYourComponentLibPocImageViewer = () => {

    const props =
        {
            id: " 202314825",
            designIndex: 1,
            imageIndex: 1,
            extractDesigns: true,
            navigateDesigns: true,
            designs: [
                {
                    id: "R10773657",
                    src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.JPG",
                    srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.THUMB.JPG",
                    srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.MEDIUM.JPG"
                },
                {
                    id: "R10773661",
                    src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG",
                    srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.THUMB.JPG",
                    srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.MEDIUM.JPG"
                },
                {
                    id: "R10773663",
                    src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773663/1.0/R10773663.JPG",
                    srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773663/1.0/R10773663.THUMB.JPG",
                    srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773663/1.0/R10773663.MEDIUM.JPG"
                },
                {
                    id: "R10773665",
                    src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773665/1.0/R10773665.JPG",
                    srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773665/1.0/R10773665.THUMB.JPG",
                    srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773665/1.0/R10773665.MEDIUM.JPG"
                },
                {
                    id: "R10773666",
                    src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773666/1.0/R10773666.JPG",
                    srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773666/1.0/R10773666.THUMB.JPG",
                    srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773666/1.0/R10773666.MEDIUM.JPG"
                },
                {
                    id: "R10773667",
                    src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773667/1.0/R10773667.JPG",
                    srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773667/1.0/R10773667.THUMB.JPG",
                    srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773667/1.0/R10773667.MEDIUM.JPG"
                },
                {
                    id: "R10773668",
                    src: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773668/1.0/R10773668.JPG",
                    srcThumb: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773668/1.0/R10773668.THUMB.JPG",
                    srcMedium: "https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773668/1.0/R10773668.MEDIUM.JPG"
                }

                /*
                  id: string;
            images?: DesignImage[];
            status: string;
            product?: string[];
            processingStatus?: string;
            registrationNumber?: string;
            registrationOfficeCode?: string;
            classifications?: string[];
            priorityDate?: string;
            filedDate?: string;
            renewalDueDate?: string;
            applicants?: string[];
            representatives?: string[];
            designers?: string[];
            awaitingExam?: boolean;
            awaitingFormalities?: boolean;
            inGracePeriod?: boolean;
            underExam?: boolean;
            underFormalities?: boolean;
            opi?: boolean;
                
                 */

            ]


        };

    return (
        <ImageViewerGS {...props} />
    );
};
