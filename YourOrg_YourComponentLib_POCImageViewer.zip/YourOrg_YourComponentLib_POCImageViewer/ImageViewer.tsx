// import { Carousel } from "react-responsive-carousel";
// import { MagnifierContainer, MagnifierPreview, MagnifierZoom } from "react-image-magnifiers";
// import "react-responsive-carousel/lib/styles/carousel.min.css";
// import "./styles.css";
import React, {useState} from "react";
import { Carousel } from "react-responsive-carousel";
import {Box} from "@mui/material";
import Button from "@mui/material/Button";
import Modal from "@mui/material/Modal";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader


function ImageViewer(props) {
    const {photos} = props

    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 1000,
        height: 800,
        bgcolor: 'background.paper',
        border: '2px solid #000',
        boxShadow: 24,
        p: 8,
    };
    
    /* const renderCustomThumbs = () => {
        return [
            <picture>
                <source
                    data-srcSet="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.JPG"
                    type="image/jpg"
                />
                <img
                    key="01"
                    src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.JPG"
                    alt="First Thumbnail"
                    height="90"
                />
            </picture>,
            <picture>
                <source
                    data-srcSet="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG"
                    type="image/jpg"
                />
                <img
                    key="02"
                    src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG"
                    alt="Second Thumbnail"
                    height="90"
                />
            </picture>,
            <picture>
                <source
                    data-srcSet="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG"
                    type="image/jpg"
                />
                <img
                    key="03"
                    src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG"
                    alt="Second Thumbnail"
                    height="90"
                />
            </picture>
        ];
    };

    const showMagnifier = ( currentIndex ) => {
        document.querySelectorAll('.magnifier-zoom div').forEach(( el, imageIndex ) => {
            if ( currentIndex === imageIndex ) {
                el.style.opacity = '1';
            } else {
                el.style.opaccity = '0'
            }
        })
    } */

    // console.log(props)

/*    const customRenderThumb = [
        <img src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.MEDIUM.JPG" />,
        <img src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.MEDIUM.JPG" />,
        <img src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773663/1.0/R10773663.MEDIUM.JPG" />,
        <img src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773665/1.0/R10773665.MEDIUM.JPG" />,
        <img src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773666/1.0/R10773666.MEDIUM.JPG" />,
        <img src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773667/1.0/R10773667.MEDIUM.JPG" />,
        <img src="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773668/1.0/R10773668.MEDIUM.JPG" />
    ] */

    const customRenderThumb = (children) =>

        children.map((item) => {
            console.log("001S");
            console.log(item[0].props.id);
            return <img src={`https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/${item[0].props.id}/1.0/${item[0].props.id}.MEDIUM.JPG`} />;
        });
    
    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    
    console.log(photos)

    const customRenderItem = (item, props) => <item.type {...item.props} {...props} />;
    
    return (

        <div>
            <Button onClick={handleOpen}>View all images</Button>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <Carousel showArrows={false}  renderThumbs={customRenderThumb}>
                        
                        {[photos.map(x => (
                        <div id={x.id}>
                            <img src={x.src} width={400} height={300}/>
                        </div>
                        ))]}
                        
                        {/* <div key="slide1">
                            <img src="http://placehold.it/350x150" />
                        </div>
                        <div key="slide2">
                            <img src="http://placehold.it/255x150" />
                        </div>
                        <div key="slide3">
                            <img src="http://placehold.it/295x150" />
                        </div>
                        <div key="slide4">
                            <img src="http://placehold.it/310x150" />
                        </div>
                        <div key="slide5">
                            <img src="http://placehold.it/575x250" />
                        </div>
                        <div key="slide6">
                            <img src="http://placehold.it/450x150" />
                        </div> */}
                    </Carousel>
                    {/*                         <Carousel dynamicHeight>
                            {getImageDivs()}
                            <div>
                                <img src={photos[0].src}/>
                            </div>
                            <div>
                                <img src={photos[1].src}/>
                            </div>                            
                            
                            <ImageViewer {...props}/>
                        </Carousel> */}
                </Box>
            </Modal>
        </div>
        

    )
    
    
/*    (

        <>
        {photos.map(x => (
                <div id={x.id}>
                    <img src={x.src} />

                </div>
            ))}
        </> */
       /* <>
            <MagnifierContainer>
                <div className="magnifier-content">
                    <div className="magnifier-carousel">
                        <Carousel
                            showArrows={false}
                            showStatus
                            showIndicators
                            showThumbs
                            autoPlay={false}
                            transitionTime={500}
                            swipeable={false}
                            emulateTouch
                            renderThumbs={renderCustomThumbs}
                            onChange={showMagnifier}
                            width="700px"
                            dynamicHeight
                        >
                            <div>
                                <MagnifierPreview
                                    imageSrc="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.JPG"
                                    imageAlt="First Slide"
                                    alwaysInPlace={false}
                                    fillAvailableSpace
                                    fillAlignTop
                                    fillGapRight={10}
                                    fillGapBottom={10}
                                    fillGapTop={10}
                                    fillGapLeft={0}
                                />
                            </div>
                            <div>
                                <MagnifierPreview
                                    imageSrc="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG"
                                    imageAlt="Second Slide"
                                    alwaysInPlace={false}
                                    fillAvailableSpace
                                    fillAlignTop
                                    fillGapRight={10}
                                    fillGapBottom={10}
                                    fillGapTop={10}
                                    fillGapLeft={0}
                                />
                            </div>
                            <div>
                                <MagnifierPreview
                                    imageSrc="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG"
                                    imageAlt="Second Slide"
                                    alwaysInPlace={false}
                                    fillAvailableSpace
                                    fillAlignTop
                                    fillGapRight={10}
                                    fillGapBottom={10}
                                    fillGapTop={10}
                                    fillGapLeft={0}
                                />
                            </div>
                        </Carousel>
                    </div>
                    <div className="magnifier-zoom">
                        <MagnifierZoom style={{ height: "800px", width: "800px" }} imageSrc="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773657/1.0/R10773657.JPG"/>
                        <MagnifierZoom style={{ height: "800px", width: "800px", borderColor: "black", 
                            border: "2", backgroundColor: "#000000" }} 
                                       imageSrc="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG"/>
                        <MagnifierZoom style={{ height: "800px", width: "800px", borderColor: "black",
                            border: "2", backgroundColor: "#000000" }}
                                       imageSrc="https://cdn2.search.ipaustralia.gov.au/202314719/STD_DESIGN/R10773661/1.0/R10773661.JPG"/>
                    </div>
                </div>
            </MagnifierContainer>
        </> */
    // );
}

export default ImageViewer;