<template>
    <uik-popup class="design-popup"
               size="full"
               :mobile-mode="mobileMode"
               :no-buttons="true"
               :no-padding="true"
               @close="close">
        <template #header>
            <div class="design-popup-header">
                <h2 class="title" id="dialog-label">
                    Representations of
                    <a href="#" @click.stop.prevent="showDetails()">
                        {{design.id}}
                        <uik-icon :icon="['fas', 'external-link-alt']"></uik-icon>
                    </a>
                </h2>

                <div class="header-buttons">
                    <button v-if="!mobileMode && data.extractDesigns"
                            class="extract primary toggle square"
                            :class="{fill: isExtracted}"
                            :title="isExtracted ? 'Remove from my list' : 'Add to my list'"
                            @click.stop.prevent="toggleExtract(design, !isExtracted)">
                        <uik-icon :icon="['fas', 'flag']"/>
                    </button>

                    <button v-if="!mobileMode && data.navigateDesigns"
                            class="primary square"
                            @click.stop.prevent="prevDesign()">
                        <uik-icon :icon="['fas', 'angle-left']"/>
                    </button>

                    <span>Result {{data.designIndex + 1}} of {{data.designs.length}}</span>

                    <button v-if="!mobileMode && data.navigateDesigns"
                            class="primary square"
                            @click.stop.prevent="nextDesign()">
                        <uik-icon :icon="['fas', 'angle-right']"/>
                    </button>
                </div>
            </div>
        </template>

        <template #content v-if="data">
            <div class="design-popup-content">
                <button class="primary icon no-fill prev-image-btn"
                        @click="prevImage()">
                    <uik-icon :icon="['fas', 'chevron-up']" :rotation="(mobileMode ? 270 : null)"/>
                </button>

                <div class="controls">
                    <ol class="thumbs">
                        <li v-for="(thumb, thumbIndex) in thumbs"
                            ref="thumbs"
                            :key="thumbIndex"
                            class="thumb"
                            :class="{selected: thumbIndex === imageIndex}"
                            @click="doShowImage(designIndex, thumbIndex)">
                            <button :aria-current="thumbIndex === imageIndex">
                                <img :src="thumb" :alt="'Representation #' + (thumbIndex + 1)">
                            </button>
                        </li>
                    </ol>
                </div>

                <button class="primary icon no-fill next-image-btn"
                        @click="nextImage()">
                    <uik-icon :icon="['fas', 'chevron-down']" :rotation="(mobileMode ? 270 : null)"/>
                </button>

                <div class="design-image-container"
                     ref="designImageContainer"
                     @mousemove="zoom($event)"
                     @mouseleave="zoom(null)"
                     @click="nextZoom($event)">
                    <img ref="designImage" :src="imageUrl" :style="imageStyle"
                         :alt="'Representation #' + (imageIndex + 1)">

                    <div v-show="showImageZoom"
                         class="design-image-zoom"
                         ref="designImageZoom">
                    </div>

                    <ul class="image-controls">
                        <li>
                            <button class="primary no-fill rotate-left has-tooltip2"
                                    @click.stop="rotate('left')">
                                <uik-icon :icon="['fas', 'undo']"></uik-icon>
                                <span class="tooltip2">Rotate left</span>
                            </button>
                        </li>

                        <li>
                            <button class="primary no-fill rotate-right has-tooltip2"
                                    @click.stop="rotate('right')">
                                <uik-icon :icon="['fas', 'redo']"></uik-icon>
                                <span class="tooltip2">Rotate right</span>
                            </button>
                        </li>

                        <li v-if="!mobileMode">
                            <button class="primary zoom has-tooltip2"
                                    :class="imageZoomScaleIndex < 1 ? 'no-fill' : imageZoomScaleIndex < 2 ? 'half' : 'fill'"
                                    @keydown.enter.space.stop.prevent="openFullSize()"
                                    @click.stop="nextZoom($event)">
                                <uik-icon :icon="['fas', 'search-plus']"></uik-icon>
                                <span class="tooltip2">{{imageZoomScaleTooltip}}</span>
                            </button>
                        </li>

                        <li>
                            <a class="button primary full-size has-tooltip2"
                               :href="fullSizeImageLink"
                               target="_blank"
                               tabindex="0"
                               @click.stop>
                                <uik-icon :icon="['fas', 'external-link-alt']"></uik-icon>
                                <span class="tooltip2">Full size</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </template>
    </uik-popup>
</template>

<script lang="ts">
import {Component, Emit, Prop, Vue} from 'vue-property-decorator';
import {DesignResult} from '../../core/models/design-data';
import {DesignPopupData} from '../../core/models/types';
import store from '../../core/store';
import Utils from '../../core/utils/utils';
import {WindowData} from '../../core/utils/window-data';

const rotations = [0, 90, 180, 270] as const;
type Rotation = typeof rotations[number];

const zoomSize = 400;
const zoomScales = [0, 2, 4] as const;
type ZoomScale = typeof zoomScales[number];

@Component
export default class DesignPopup extends Vue {
    @Prop() data!: DesignPopupData;

    hoveringIndex: number | null = null;
    imageContainerRect: {width: number, height: number, top: number, left: number} | null = null;
    imageNaturalSize: {width: number, height: number} | null = null;
    imageRect: {width: number, height: number, top: number, left: number, scale: number} | null = null;
    imageRotation: Rotation = 0;
    imageZoomScale: ZoomScale = zoomScales[0];
    showImageZoom = false;

    mounted() {
        window.addEventListener('keydown', this.keydown);
        window.addEventListener('resize', this.updateLayout);

        const designImage = this.$refs.designImage as HTMLImageElement;
        designImage.onload = this.updateLayout;

        window.setTimeout(() => this.scrollActiveThumbIntoView(this.imageIndex), 100);
    }

    destroyed() {
        window.removeEventListener('keydown', this.keydown);
        window.removeEventListener('resize', this.updateLayout);
    }

    get mobileMode(): boolean {
        return store.mobileMode;
    }

    get isExtracted(): boolean {
        return !!store.extracts.extract(this.design.id);
    }

    get design(): DesignResult {
        return this.data.designs[this.data.designIndex];
    }

    get designIndex(): number {
        return this.data.designIndex;
    }

    get imageIndex(): number {
        return this.data.imageIndex;
    }

    get imageUrl(): string {
        if (!this.design.images || this.design.images.length === 0) {
            return '';
        }

        const index = ((typeof this.hoveringIndex === 'number' ? this.hoveringIndex : this.imageIndex) || 0);
        let i = this.design.images[index];
        return Utils.imageUrl(this.design.id, i);
    }

    get imageStyle(): Partial<CSSStyleDeclaration> {
        if (!this.imageRect) {
            return {};
        }

        let top = this.imageRect.top;
        let left = this.imageRect.left;
        switch (this.imageRotation) {
            case 90:
                left += this.imageRect.height;
                break;
            case 180:
                top += this.imageRect.height;
                left += this.imageRect.width;
                break;
            case 270:
                top += this.imageRect.width;
                break;
        }

        return {
            top: `${top}px`,
            left: `${left}px`,
            width: `${this.imageRect.width}px`,
            height: `${this.imageRect.height}px`,
            transform: `rotate(${this.imageRotation}deg)`
        };
    }

    get thumbs(): string[] {
        if (!this.design.images) {
            return [];
        }

        return this.design.images.map(x => Utils.imageUrl(this.design.id, x, 'THUMB'));
    }

    get imageZoomScaleIndex(): number {
        return zoomScales.indexOf(this.imageZoomScale);
    }

    get imageZoomScaleTooltip(): string {
        let index = zoomScales.indexOf(this.imageZoomScale) + 1;
        if (index > zoomScales.length - 1) {
            index = 0;
        }

        if (index === 0) {
            return `Turn off zoom`;
        }

        return `Zoom ${zoomScales[index]}x on hover`;
    }

    get fullSizeImageLink(): string {
        if (!this.design.images) {
            return '';
        }

        return `${WindowData.baseUrl}/search/details/${this.design.id}/representation/?i=${this.design.images[this.imageIndex].i}&v=${this.design.images[this.imageIndex].v}`;
    }

    @Emit()
    toggleExtract(result: DesignResult, toggle: boolean) {
    }

    @Emit()
    showImage(designIndex: number, imageIndex: number) {
    }

    @Emit()
    close() {
    }

    rotate(rotation: 'left' | 'right' | 'clear') {
        let index = rotations.indexOf(this.imageRotation);
        switch (rotation) {
            case 'left':
                index = (index > 0 ? index - 1 : rotations.length - 1);
                break;
            case 'right':
                index = (index < rotations.length - 1 ? index + 1 : 0);
                break;
            default:
                index = 0;
                break;
        }

        this.imageRotation = rotations[index];
        this.updateLayout();
    }

    nextZoom(event: MouseEvent) {
        if (this.mobileMode) {
            return;
        }

        let index = zoomScales.indexOf(this.imageZoomScale) + 1;
        if (index > zoomScales.length - 1) {
            index = 0;
        }

        this.imageZoomScale = zoomScales[index];
        this.zoom(event);
    }

    openFullSize() {
        window.open(this.fullSizeImageLink, '_blank');
    }

    zoom(event: MouseEvent) {
        if (this.mobileMode) {
            return;
        }

        const designImageZoom = this.$refs.designImageZoom as HTMLElement;
        if (!this.imageContainerRect || !this.imageNaturalSize || !this.imageRect || !this.imageZoomScale || !designImageZoom || !event) {
            this.showImageZoom = false;
            return;
        }

        // zoom position and size
        const rotate = rotations.indexOf(this.imageRotation);
        designImageZoom.style.top = `${event.clientY - this.imageContainerRect.top - zoomSize / 2}px`;
        designImageZoom.style.left = `${event.clientX - this.imageContainerRect.left - zoomSize / 2}px`;
        designImageZoom.style.width = `${zoomSize}px`;
        designImageZoom.style.height = `${zoomSize}px`;
        designImageZoom.style.transform = `rotate(${rotate * 90}deg)`;

        // zoom background
        const swapDims = (Math.abs(rotate % 2) === 1);
        const rotatedImageRect = {
            ...this.imageRect,
            width: (swapDims ? this.imageRect.height : this.imageRect.width),
            height: (swapDims ? this.imageRect.width : this.imageRect.height)
        };

        const invertX = (rotate === 1 || rotate === 2);
        const invertY = (rotate === 2 || rotate === 3);
        const imageX = (invertX ? rotatedImageRect.width : 0) + (invertX ? -1 : 1) * (event.clientX - this.imageContainerRect.left - rotatedImageRect.left);
        const imageY = (invertY ? rotatedImageRect.height : 0) + (invertY ? -1 : 1) * (event.clientY - this.imageContainerRect.top - rotatedImageRect.top);
        const rotatedImageX = (swapDims ? imageY : imageX);
        const rotatedImageY = (swapDims ? imageX : imageY);
        const bgScale = this.imageZoomScale * this.imageRect.scale;
        designImageZoom.style.backgroundImage = `url(${this.imageUrl})`;
        designImageZoom.style.backgroundSize = `${this.imageNaturalSize.width * bgScale}px ${this.imageNaturalSize.height * bgScale}px`;
        designImageZoom.style.backgroundPosition = `${-rotatedImageX * this.imageZoomScale + zoomSize / 2}px ${-rotatedImageY * this.imageZoomScale + zoomSize / 2}px`;

        this.showImageZoom = true;
    }

    prevImage() {
        this.doShowImage(this.designIndex, this.imageIndex - 1, 'prev');
    }

    nextImage() {
        this.doShowImage(this.designIndex, this.imageIndex + 1, 'next');
    }

    prevDesign() {
        this.doShowImage(this.designIndex - 1, 0);
    }

    nextDesign() {
        this.doShowImage(this.designIndex + 1, 0);
    }

    showDetails() {
        const query = this.$route.query;
        if (this.$route.name === 'extracts') {
            query.x = '1';
        }

        this.$router.push({
            name: 'details',
            params: {applicationNumber: this.design.id},
            query
        });

        this.close();
    }

    doShowImage(designIndex: number, imageIndex: number, imageDirection?: string) {
        this.rotate('clear');

        // TODO thumb into view if necessary??

        // loop thru previews if we're not going thru designs
        if (!this.data.navigateDesigns && imageDirection && this.data.designs[designIndex].images) {
            if (imageDirection === 'next') {
                if (this.data.designs[designIndex].images!.length === imageIndex) {
                    imageIndex = 0;
                }
            } else {
                if (imageIndex === -1) {
                    imageIndex = this.data.designs[designIndex].images!.length - 1;
                }
            }
        }

        if (designIndex !== this.designIndex) {
            // skip designs with no images
            const delta = (designIndex < this.designIndex ? -1 : 1);
            while (
                designIndex >= 0 && designIndex < this.data.designs.length && !this.hasImages(designIndex)) {
                designIndex += delta;
            }

            if (designIndex < 0 || designIndex > this.data.designs.length - 1) {
                designIndex = this.designIndex;
                imageIndex = this.imageIndex;
            }
        }

        if (imageIndex !== this.imageIndex) {
            const design = this.data.designs[designIndex];
            imageIndex = Math.max(0, imageIndex);
            imageIndex = Math.min((design.images ? design.images.length - 1 : 0), imageIndex);
        }

        this.showImage(designIndex, imageIndex);
        this.scrollActiveThumbIntoView(imageIndex);
    }

    private hasImages(designIndex: number): boolean {
        return (!!this.data.designs[designIndex].images && this.data.designs[designIndex].images!.length > 0);
    }

    private updateLayout() {
        const designImageContainer = this.$refs.designImageContainer as HTMLElement;
        const designImage = this.$refs.designImage as HTMLImageElement;
        if (!designImageContainer || !designImage) {
            this.imageContainerRect = null;
            this.imageNaturalSize = null;
            this.imageRect = null;
            return;
        }

        this.imageContainerRect = designImageContainer.getBoundingClientRect();
        this.imageNaturalSize = {
            width: designImage.naturalWidth,
            height: designImage.naturalHeight
        };

        // rotated dimensions
        const rotate = rotations.indexOf(this.imageRotation);
        const swapDims = (Math.abs(rotate % 2) === 1);
        const containerRotatedWidth = (swapDims ? this.imageContainerRect.height : this.imageContainerRect.width);
        const containerRotatedHeight = (swapDims ? this.imageContainerRect.width : this.imageContainerRect.height);

        // image aspect ratio scaled down if needed
        const wScale = Math.min(containerRotatedWidth / this.imageNaturalSize.width, 1);
        const hScale = Math.min(containerRotatedHeight / this.imageNaturalSize.height, 1);
        const scale = Math.min(wScale, hScale);

        // scaled dimentions and position
        const width = this.imageNaturalSize.width * scale;
        const height = this.imageNaturalSize.height * scale;
        const rotatedWidth = (swapDims ? height : width);
        const rotatedHeight = (swapDims ? width : height);
        this.imageRect = {
            width,
            height,
            top: (this.imageContainerRect.height - rotatedHeight) / 2,
            left: (this.imageContainerRect.width - rotatedWidth) / 2,
            scale
        };
    }

    private scrollActiveThumbIntoView(index: number) {
        const thumbs = this.$refs.thumbs as HTMLElement[];
        if (thumbs && index >= 0 && index < thumbs.length) {
            thumbs[index].scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });
        }
    }

    private keydown(e: Event) {
        switch ((e as KeyboardEvent).key) {
            case 'ArrowRight':
                e.stopPropagation();
                e.preventDefault();
                this.nextDesign();
                break;
            case 'ArrowLeft':
                e.stopPropagation();
                e.preventDefault();
                this.prevDesign();
                break;
            case 'ArrowUp':
                e.stopPropagation();
                e.preventDefault();
                this.prevImage();
                break;
            case 'ArrowDown':
                e.stopPropagation();
                e.preventDefault();
                this.nextImage();
                break;
            case 'r':
                if (!(e as KeyboardEvent).ctrlKey) {
                    e.stopPropagation();
                    e.preventDefault();
                    this.rotate('right');
                }
                break;
        }
    }
}
</script>

<style scoped lang="scss">
#popup-base.design-popup {
    .design-popup-header {
        width: 100%;
        display: flex;
        align-items: center;

        .title {
            width: 50%;
            flex: 1 auto;
            font-size: 1rem;
            margin: 0;
            padding: 0;
            font-weight: 600;

            a {
                color: $ipaCharcoal;
                text-decoration: none;

                svg {
                    font-size: .8rem;
                    margin-bottom: 0.15rem;
                }

                &:hover {
                    text-decoration: underline;
                }
            }
        }

        .header-buttons {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            width: 50%;
            margin-right: .5rem;

            button {
                &:first-of-type {
                    margin-right: .5rem;
                }
            }

            span {
                flex: 0 auto !important;
                margin: 0 0.3em;
            }
        }
    }

    .design-popup-content {
        display: flex;
        position: relative;
        width: 100%;
        height: 100%;
        background: white;

        .prev-image-btn,
        .next-image-btn {
            position: absolute;
            left: calc(4rem - 17.5px);
            z-index: 999;

            &:focus {
                outline: auto;
            }
        }

        .prev-image-btn {
            top: 15px;
        }

        .next-image-btn {
            bottom: 15px;
        }

        .controls {
            flex: auto 0;
            width: 8rem;
            height: 100%;
            padding: 4rem 0;
            box-sizing: border-box;
            background: $sidebarBg;
            overflow: auto;

            .thumbs {
                width: 5rem;
                margin: 0 auto;
                padding: 0;
                text-align: center;
                list-style-type: none;

                .thumb {
                    position: relative;
                    width: 100%;
                    margin-bottom: 0.5rem;
                    border-radius: 3px;
                    background: #ffffff;
                    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
                    cursor: pointer;
                    transition: all 0.3s ease;

                    button {
                        width: 100%;
                        height: auto;
                        box-shadow: none;
                        border: 0;
                        margin: 0;
                        padding: 0;

                        &:focus {
                            outline: auto;
                        }
                    }

                    @include ie() {
                        max-height: 100px;
                        align-items: center;
                        justify-content: center;
                    }

                    img {
                        border-radius: 3px;
                        display: block;
                        height: auto;
                        object-fit: scale-down;
                        width: 100%;

                        @include ie() {
                            max-height: 100px;
                        }
                    }

                    &.selected {
                        &::after {
                            background: $externalPrimary;
                            bottom: 0;
                            content: "";
                            height: 4px;
                            left: 0;
                            position: absolute;
                            width: 100%;
                            border-radius: 0 0 3px 3px;
                        }
                    }

                    &:last-child {
                        margin-bottom: 0;
                    }
                }
            }
        }

        .design-image-container {
            flex: 1 auto;
            position: relative;
            width: calc(100% - 140px);
            overflow: hidden;
            cursor: zoom-in;

            img {
                position: absolute;
                top: 0;
                left: 0;
                transform-origin: top left;
            }

            .design-image-zoom {
                position: absolute;
                border-radius: 50%;
                box-sizing: border-box;
                background-color: white;
                background-repeat: no-repeat;

                &::before,
                &::after {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    border: 3px solid white;
                    border-radius: 50%;
                    box-sizing: border-box;
                }

                &::before {
                    box-shadow: 0 0 5px 1px rgba(0, 0, 0, 0.5);
                }

                &::after {
                    box-shadow: inset 0 0 5px 1px rgba(0, 0, 0, 0.5);
                }
            }

            .image-controls {
                display: flex;
                align-items: center;
                justify-content: space-between;
                position: absolute;
                top: 0;
                left: calc(50% - 4rem);
                width: 8rem;
                padding: 0.5rem;
                border-radius: 0 0 3px 3px;
                box-sizing: border-box;
                background: rgba(255, 255, 255, 0.5);
                box-shadow: 0 0 2px rgba(0, 0, 0, 0.26);

                button,
                .button {
                    flex: auto 0;
                    width: 1.5rem;
                    height: 1.5rem;
                    padding: 0;
                    border-radius: 50%;
                    background: white;
                    color: $externalPrimary;
                    font-size: 0.8rem;
                    cursor: pointer;

                    &.half {
                        background: linear-gradient(lighten($externalPrimary, 30%) 50%, $externalPrimary 50%);
                        color: white;
                    }

                    &.fill {
                        background: $externalPrimary;
                        color: white;
                    }
                }
            }
        }

        .prev-image-btn,
        .next-image-btn {
            flex: auto 0;
            border: none;
            border-radius: 50%;
            font-size: 1.2rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
        }

    }

    &.mobile-mode {
        ::v-deep .content {
            width: 100vw;
            height: 100vh;
            max-width: 100vw;
            max-height: 100vh;
        }

        .design-popup-header {
            .title {
                width: 100%;
            }

            .header-buttons {
                display: none;
            }
        }

        .design-popup-content {
            flex-direction: column-reverse;

            .prev-image-btn,
            .next-image-btn {
                top: auto;
                bottom: calc(3.5rem - 16px);
                left: auto;
                right: auto;
            }

            .prev-image-btn {
                left: 10px;
            }

            .next-image-btn {
                right: 10px;
            }

            .controls {
                display: flex;
                align-items: center;
                width: 100%;
                height: 7rem;
                padding: 0 4rem;

                .thumbs {
                    width: max-content;
                    height: 5rem;
                    margin: 0;
                    white-space: nowrap;

                    .thumb {
                        display: inline-block;
                        max-width: none;
                        width: auto;
                        height: 100%;
                        margin-bottom: 0;
                        margin-right: 0.5rem;

                        button {
                            width: auto;
                            height: 100%;
                            box-shadow: none;
                        }

                        img {
                            width: auto;
                            height: 100%;
                        }

                        &:last-child {
                            margin-right: 4rem;
                        }
                    }
                }
            }

            .design-image-container {
                width: auto;
                height: calc(100% - 140px);
                cursor: default;
            }

            .prev-image-btn,
            .next-image-btn {
            }
        }
    }
}
</style>
