import PropTypes from 'prop-types';
import React from 'react';
import { useState } from "react"
import {ArrowBackIos} from "@material-ui/icons";
import {ArrowForwardIos} from "@material-ui/icons";
import CircleIcon from '@mui/icons-material/Circle';
import AdjustIcon from '@mui/icons-material/Adjust';

import StyledYourOrgYourComponentLibPocImageViewerWrapper from './styles';


// Duplicated runtime code from Constellation Design System Component

// props passed in combination of props from property panel (config.json) and run time props from Constellation
// any default values in config.pros should be set in defaultProps at bottom of this file

type ImageViewerProps = {
  images: Array<{
    key: string,
    url: string
    alt: string
  }>
}

export default function YourOrgYourComponentLibPocImageViewer({ images }: ImageViewerProps) {

  const [imageIndex, setImageIndex] = useState(0)

  function showNextImage() {
    setImageIndex(index => {
      if (index === images.length - 1) return 0
      return index + 1
    })
  }

  function showPrevImage() {
    setImageIndex(index => {
      if (index === 0) return images.length - 1
      return index - 1
    })
  }


  
  
  
  return (
    <StyledYourOrgYourComponentLibPocImageViewerWrapper>
      <section
          aria-label="Image Slider"
          style={{ width: "100%", height: "100%", position: "relative" }}
      >
        <a href="#after-image-slider-controls" className="skip-link">
          Skip Image Slider Controls
        </a>
        <div
            style={{
              width: "100%",
              height: "100%",
              display: "flex",
              overflow: "hidden",
            }}
        >
          {images.map(({ url, alt }, index) => (
              <img
                  key={url}
                  src={url}
                  alt={alt}
                  aria-hidden={imageIndex !== index}
                  className="img-slider-img"
                  style={{ translate: `${-100 * imageIndex}%` }}
              />
          ))}
        </div>
        <button
            onClick={showPrevImage}
            className="img-slider-btn"
            style={{ left: 0 }}
            aria-label="View Previous Image"
        >
          <ArrowBackIos aria-hidden />
        </button>
        <button
            onClick={showNextImage}
            className="img-slider-btn"
            style={{ right: 0 }}
            aria-label="View Next Image"
        >
          <ArrowForwardIos aria-hidden />
        </button>
        <div
            style={{
              position: "absolute",
              bottom: ".5rem",
              left: "50%",
              translate: "-50%",
              display: "flex",
              gap: ".25rem",
            }}
        >
          {images.map((image, index) => (
              <button
                  key={image.key}
                  className="img-slider-dot-btn"
                  aria-label={`View Image ${image.key}`}
                  onClick={() => setImageIndex(index)}
              >
                {index === imageIndex ? (
                    /*<AdjustIcon aria-hidden />*/ <img
                    key={image.url}
                    src={image.url}
                    height={100}
                    width={100}
                    // alt={alt}
                    aria-hidden={imageIndex !== index}
                    className="img-slider-img"
                    style={{ translate: `${-100 * imageIndex}%` }}
                />
                ) : (

                    <img
                        key={image.url}
                        src={image.url}
                        height={100}
                        width={100}
                        // alt={alt}
                        aria-hidden={imageIndex !== index}
                        className="img-slider-img"
                        style={{ translate: `${-100 * imageIndex}%` }}
                    />
                    
                   /* <CircleIcon aria-hidden />*/
                )}
              </button>
          ))}
        </div>
        <div id="after-image-slider-controls" />
      </section>
    </StyledYourOrgYourComponentLibPocImageViewerWrapper>
  );

}

YourOrgYourComponentLibPocImageViewer.defaultProps = {
  // header: '',
  // description: '',
  // image: '',
  // datasource: [],
  // whatsnewlink: ''
};

YourOrgYourComponentLibPocImageViewer.propTypes = {
   // header: PropTypes.string,
  // description: PropTypes.string,
  // datasource: PropTypes.instanceOf(Object),
  // whatsnewlink: PropTypes.string,
  // image: PropTypes.string
};

