import React, {useEffect, useRef, useState, MouseEvent} from 'react';

import StyledYourOrgYourComponentLibPocImageViewerWrapper from './styles';
import {createStyles, makeStyles, Theme} from "@material-ui/core/styles";
import Button from "@mui/material/Button";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";

import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import {Text} from '@pega/cosmos-react-core';
import {StyledGridContainer, StyledGridItem} from "./Grid.styles";

import {Dialog, ImageList, ImageListItem} from "@mui/material";
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
/* import styled from "styled-components"; */

import {styled} from '@mui/material/styles';
import {ArrowBackIos, ArrowForwardIos} from "@material-ui/icons";

export default function ImageViewerGS(props) {

    const [imageIndex, setImageIndex] = useState(0)
    const mobileMode = false

    const rotations = [0, 90, 180, 270] as const;
    type Rotation = typeof rotations[number];

    const zoomSize = 400;
    const zoomScales = [0, 2, 4] as const;
    type ZoomScale = typeof zoomScales[number];


    // const hoveringIndex: number | null = null;
    const [hoveringIndex, setHoveringIndex] = useState<number | null>(null);
    const [imageContainerRect, setImageContainerRect] = useState<{
        width: number,
        height: number,
        top: number,
        left: number
    } | null | DOMRect>(null);
    const [imageNaturalSize, setImageNaturalSize] = useState<{ width: number, height: number } | null>(null);
    const [imageRect, setImageRect] = useState<{
        width: number,
        height: number,
        top: number,
        left: number,
        scale: number
    } | null>(null);

    // imageRotation: Rotation = 0;
    const [imageRotation, setImageRotation] = useState<Rotation>(0);

    // imageZoomScale: ZoomScale = zoomScales[0];
    const [imageZoomScale, setImageZoomScale] = useState<ZoomScale>(zoomScales[1]);
    const [showImageZoom, setShowImageZoom] = useState<boolean>(false);

    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const Item = styled(Paper)(({theme}) => ({
        backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
        // ...theme.typography.body2,
        padding: theme.spacing(1),
        color: theme.palette.text.secondary,
        borderRadius: 1,
        elevation: 0,
        boxShadow: "none",
        border: '0.5px solid lightgray'
    }));


    function showNextImage() {
        setImageIndex(index => {
            if (index === props.designs.length - 1) return 0
            return index + 1
        })
    }

    function showPrevImage() {
        setImageIndex(index => {
            if (index === 0) return props.designs.length - 1
            return index - 1
        })
    }

    type Design = {
        // [key: string]: any;
        id: string; // "R10773
        src: string; //  "https
        srcThumb: string; // 
        srcMedium: string; // 
    };
    
    function findObjectByPropertyValue(objects: Array<Design>, propertyName: keyof Design, propertyValue: any): number {
        // return objects.find(obj => obj[propertyName] === propertyValue);
        return objects.findIndex(obj => obj[propertyName] === propertyValue);


    }
    
    
    function ThumbnailList(){
        return(
        <>
            <Button
                onClick={showPrevImage}
                className="img-slider-btn"
                style={{ alignItems: 'centre', top: 0 }}
                aria-label="View Previous Image"
            >
                <ExpandLessIcon aria-hidden />
            </Button>
            <Button
                onClick={showNextImage}
                className="img-slider-btn"
                style={{ bottom: 0 }}
                aria-label="View Next Image"
            >
                <ExpandMoreIcon aria-hidden />
            </Button>
{/*            <Grid item xs={2}
                style={{
                    position: "absolute",
                    // bottom: ".5rem",
                    // left: "50%",
                    // translate: "-50%",
                    display: "flex",
                    gap: ".25rem",
                    
                }}
            > */}
{/*                {props.designs.map((image, index) => (
                    <Button
                        key={image.key}
                        className="img-slider-dot-btn"
                        aria-label={`View Image ${image.key}`}
                        onClick={() => setImageIndex(index)}
                    >
                    <img
                        key={image.id}
                        src={image.srcMedium}
                        height={100}
                        width={100}
                        // alt={alt}
                        aria-hidden={imageIndex !== index}
                        className="img-slider-img"
                        style={{ translate: `${-100 * imageIndex}%` }}
                    />

                    </Button>
                ))} */}


                <ImageList sx={{ height: 600 }} cols={1}>
                    {props.designs.map((image, index) => (
                        <Button
                            key={image.key}
                            className="img-slider-dot-btn"
                            aria-label={`View Image ${image.id}`}
                            onClick={() => setImageIndex(index)}
                        >
                            <ImageListItem key={image.id}>
                                <img
                                    // srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                                    src={`${image.srcMedium}`}
                                    // alt={item.title}
                                    height={100}
                                    width={100}
                                    loading="lazy"
                                    
                                />
                            </ImageListItem>
                        </Button>
                    ))}
                </ImageList>
                
                
            {/* </Grid> */}
        </>
        )
    }
    
    function MainImage(){
        
        return(
/*        <section
            aria-label="Image Slider"
            style={{ width: "100%", height: "100%", position: "relative" }}
        >
            <div
                style={{
                    width: "100%",
                    height: "100%",
                    display: "flex",
                    overflow: "hidden",
                    alignItems: "center"
                    
                }}
            > */
                    <img
                        key={imageIndex}
                       //  src={findObjectByPropertyValue(props.designs, "id", imageIndex).src}
                        src={props.designs[imageIndex].src}
                        // height={400}
                        // width={"100pc"}
                        // aria-hidden={imageIndex !== index}
                        className="img-slider-img"
                       /* style={{ translate: `${-100 * imageIndex}%`, */
                        style={{ 
                            objectFit: "cover",
                            maxWidth: "600px",
                            maxHeight: "600px",
                            // aspectRatio: "10 / 6",
                            display: "block",
                            flexShrink: 0,
                            flexGrow: 0}}
                   
                    />
/*            </div>
            
            {/!* <div id="after-image-slider-controls" /> *!/}
        </section> */
        )
    }
    function ImageV() {
        return (
            <Grid container spacing={0}>
                <Grid item xs={6}>
                    <Item sx={{borderRight: 0, borderBottom: 0}}>Representations of {props.id}</Item>
                </Grid>
                <Grid item xs={6}>
                    <Item sx={{textAlign: 'right', borderBottom: 0, borderLeft: 0}}>Result 1 of {props.designs.length}</Item>
                </Grid>
                <Grid item xs={2}>
                    {/* <Item sx={{borderRight: 0, borderBottom: 0}}> */}
                        <ThumbnailList/>
                   {/* </Item> */}
                </Grid>
                <Grid item xs={10}>
                    <Item sx={{textAlign: 'center'}}>
                        <MainImage/>
                    </Item>
                </Grid>
            </Grid>
        )
    }

    return (
        <StyledYourOrgYourComponentLibPocImageViewerWrapper>
            <ImageV/>
            <Button onClick={handleOpen} className="MuiModal-root">Open gallery</Button>
            <Dialog onClose={handleClose} open={open} maxWidth='lg' fullWidth>
                <ImageV/>
            </Dialog>
        </StyledYourOrgYourComponentLibPocImageViewerWrapper>
    );
};
