// utilizing theming, comment out, if want individual style
// import styled from 'styled-components';
// import { Configuration } from '@pega/cosmos-react-core';

// export default styled(Configuration)``;

// individual style, comment out above, and uncomment here and add styles
 import styled, { css } from 'styled-components';

 export default styled.div(() => {
  return css`
   *,
   *::before,
   *::after {
    box-sizing: border-box;
   }

   .img-slider-img {
    object-fit: cover;
    width: 100%;
    height: 100%;
    display: block;
    flex-shrink: 0;
    flex-grow: 0;
   }

   .MuiDialog-root > .MuiGrid-item > .img-slider-btn {
    all: unset;
    display: block;
    position: absolute;
    top: 0;
    bottom: 0;
    padding: 1rem;
    cursor: pointer;
    transition: background-color 100ms ease-in-out;
   }

   .img-slider-btn:hover,
   .img-slider-btn:focus-visible {
      background-color: rgb(0, 0, 0, 0.2);
   }

   .img-slider-btn > * {
     stroke: white;
     fill: black;
     width: 2rem;
     height: 2rem;
   }

   @keyframes squish {
    50% {
     scale: 1.4 0.6;
    }
   }

   .img-slider-dot-btn {
    all: unset;
    display: block;
    cursor: pointer;
    width: 1rem;
    height: 1rem;
    transition: scale 100ms ease-in-out;
   }

   .img-slider-dot-btn:hover,
   .img-slider-dot-btn:focus-visible {
    scale: 1.2;
   }

   .img-slider-dot-btn > * {
    stroke: white;
    fill: black;
    height: 100%;
    width: 100%;
   }

   .img-slider-dot-btn:focus-visible,
   .img-slider-btn:focus-visible {
    outline: auto;
   }

   .skip-link {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    border: 0;
    clip: rect(0, 0, 0, 0);
   }

   .skip-link:focus-visible {
    top: 0;
    left: 0;
    border: 1px solid black;
    background-color: white;
    padding: 0.5rem;
    width: auto;
    height: auto;
    margin: 0;
    clip: unset;
    text-decoration: none;
    color: black;
    z-index: 100;
   }

   @media not (prefers-reduced-motion) {
    .img-slider-img {
     transition: translate 300ms ease-in-out;
    }

    .img-slider-btn:hover > *,
    .img-slider-btn:focus-visible > * {
     animation: squish 200ms ease-in-out;
    }
   }

   /*#popup-base.design-popup {
    .design-popup-header {
     width: 100%;
     display: flex;
     align-items: center;

     .title {
      width: 50%;
      flex: 1 auto;
      font-size: 1rem;
      margin: 0;
      padding: 0;
      font-weight: 600;

      a {
       color: $ipaCharcoal;
       text-decoration: none;

       svg {
        font-size: .8rem;
        margin-bottom: 0.15rem;
       }

       &:hover {
        text-decoration: underline;
       }
      }
     }

     .header-buttons {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      width: 50%;
      margin-right: .5rem;

      button {
       &:first-of-type {
        margin-right: .5rem;
       }
      }

      span {
       flex: 0 auto !important;
       margin: 0 0.3em;
      }
     }
    }

    .design-popup-content {
     display: flex;
     position: relative;
     width: 100%;
     height: 100%;
     background: white;

     .prev-image-btn,
     .next-image-btn {
      position: absolute;
      left: calc(4rem - 17.5px);
      z-index: 999;

      &:focus {
       outline: auto;
      }
     }

     .prev-image-btn {
      top: 15px;
     }

     .next-image-btn {
      bottom: 15px;
     }

     .controls {
      flex: auto 0;
      width: 8rem;
      height: 100%;
      padding: 4rem 0;
      box-sizing: border-box;
      background: $sidebarBg;
      overflow: auto;

      .thumbs {
       width: 5rem;
       margin: 0 auto;
       padding: 0;
       text-align: center;
       list-style-type: none;

       .thumb {
        position: relative;
        width: 100%;
        margin-bottom: 0.5rem;
        border-radius: 3px;
        background: #ffffff;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
        cursor: pointer;
        transition: all 0.3s ease;

        button {
         width: 100%;
         height: auto;
         box-shadow: none;
         border: 0;
         margin: 0;
         padding: 0;

         &:focus {
          outline: auto;
         }
        }

       @include ie() {
        max-height: 100px;
        align-items: center;
        justify-content: center;
       }

        img {
         border-radius: 3px;
         display: block;
         height: auto;
         object-fit: scale-down;
         width: 100%;

        @include ie() {
         max-height: 100px;
        }
        }

        &.selected {
         &::after {
          background: $externalPrimary;
          bottom: 0;
          content: "";
          height: 4px;
          left: 0;
          position: absolute;
          width: 100%;
          border-radius: 0 0 3px 3px;
         }
        }

        &:last-child {
         margin-bottom: 0;
        }
       }
      }
     }

     .design-image-container {
      flex: 1 auto;
      position: relative;
      width: calc(100% - 140px);
      overflow: hidden;
      cursor: zoom-in;

      img {
       position: absolute;
       top: 0;
       left: 0;
       transform-origin: top left;
      }

      .design-image-zoom {
       position: absolute;
       border-radius: 50%;
       box-sizing: border-box;
       background-color: white;
       background-repeat: no-repeat;

       &::before,
       &::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: 3px solid white;
        border-radius: 50%;
        box-sizing: border-box;
       }

       &::before {
        box-shadow: 0 0 5px 1px rgba(0, 0, 0, 0.5);
       }

       &::after {
        box-shadow: inset 0 0 5px 1px rgba(0, 0, 0, 0.5);
       }
      }

      .image-controls {
       display: flex;
       align-items: center;
       justify-content: space-between;
       position: absolute;
       top: 0;
       left: calc(50% - 4rem);
       width: 8rem;
       padding: 0.5rem;
       border-radius: 0 0 3px 3px;
       box-sizing: border-box;
       background: rgba(255, 255, 255, 0.5);
       box-shadow: 0 0 2px rgba(0, 0, 0, 0.26);

       button,
       .button {
        flex: auto 0;
        width: 1.5rem;
        height: 1.5rem;
        padding: 0;
        border-radius: 50%;
        background: white;
        color: $externalPrimary;
        font-size: 0.8rem;
        cursor: pointer;

        &.half {
         background: linear-gradient(lighten($externalPrimary, 30%) 50%, $externalPrimary 50%);
         color: white;
        }

        &.fill {
         background: $externalPrimary;
         color: white;
        }
       }
      }
     }

     .prev-image-btn,
     .next-image-btn {
      flex: auto 0;
      border: none;
      border-radius: 50%;
      font-size: 1.2rem;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
     }

    }

    &.mobile-mode {
     ::v-deep .content {
      width: 100vw;
      height: 100vh;
      max-width: 100vw;
      max-height: 100vh;
     }

     .design-popup-header {
      .title {
       width: 100%;
      }

      .header-buttons {
       display: none;
      }
     }

     .design-popup-content {
      flex-direction: column-reverse;

      .prev-image-btn,
      .next-image-btn {
       top: auto;
       bottom: calc(3.5rem - 16px);
       left: auto;
       right: auto;
      }

      .prev-image-btn {
       left: 10px;
      }

      .next-image-btn {
       right: 10px;
      }

      .controls {
       display: flex;
       align-items: center;
       width: 100%;
       height: 7rem;
       padding: 0 4rem;

       .thumbs {
        width: max-content;
        height: 5rem;
        margin: 0;
        white-space: nowrap;

        .thumb {
         display: inline-block;
         max-width: none;
         width: auto;
         height: 100%;
         margin-bottom: 0;
         margin-right: 0.5rem;

         button {
          width: auto;
          height: 100%;
          box-shadow: none;
         }

         img {
          width: auto;
          height: 100%;
         }

         &:last-child {
          margin-right: 4rem;
         }
        }
       }
      }

      .design-image-container {
       width: auto;
       height: calc(100% - 140px);
       cursor: default;
      }

      .prev-image-btn,
      .next-image-btn {
      }
     }
    }
   }*/
  `;
 });
