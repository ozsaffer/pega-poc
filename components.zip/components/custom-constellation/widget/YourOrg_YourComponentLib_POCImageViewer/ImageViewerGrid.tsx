import React, {useEffect, useRef, useState, MouseEvent} from 'react';

import StyledYourOrgYourComponentLibPocImageViewerWrapper from './styles';
import {createStyles, makeStyles, Theme} from "@material-ui/core/styles";
import Button from "@mui/material/Button";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";

import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import {Text} from '@pega/cosmos-react-core';
import {StyledGridContainer, StyledGridItem} from "./Grid.styles";

import {Dialog, ImageList, ImageListItem} from "@mui/material";
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
/* import styled from "styled-components"; */

import {styled} from '@mui/material/styles';
import {ArrowBackIos, ArrowForwardIos} from "@material-ui/icons";
import {Integer} from "@pega/react-sdk-components/lib/sdk-pega-component-map";

export default function ImageViewerGS(props) {

    const [imageIndex, _setImageIndex] = useState(0)
    const mobileMode = false

    const rotations = [0, 90, 180, 270] as const;
    type Rotation = typeof rotations[number];

    const zoomSize = 400;
    const zoomScales = [0, 2, 4] as const;
    type ZoomScale = typeof zoomScales[number];


    // const hoveringIndex: number | null = null;
    const [hoveringIndex, setHoveringIndex] = useState<number | null>(null);
    const [imageContainerRect, setImageContainerRect] = useState<{
        width: number,
        height: number,
        top: number,
        left: number
    } | null | DOMRect>(null);
    const [imageNaturalSize, setImageNaturalSize] = useState<{ width: number, height: number } | null>(null);
    const [imageRect, setImageRect] = useState<{
        width: number,
        height: number,
        top: number,
        left: number,
        scale: number
    } | null>(null);

    // imageRotation: Rotation = 0;
    const [imageRotation, setImageRotation] = useState<Rotation>(0);

    // imageZoomScale: ZoomScale = zoomScales[0];
    const [imageZoomScale, setImageZoomScale] = useState<ZoomScale>(zoomScales[1]);
    const [showImageZoom, setShowImageZoom] = useState<boolean>(false);

    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const Item = styled(Paper)(({theme}) => ({
        backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
        // ...theme.typography.body2,
        padding: theme.spacing(1),
        color: theme.palette.text.secondary,
        borderRadius: 1,
        elevation: 0,
        boxShadow: "none",
        border: '0.5px solid lightgray',
        alignItems: 'center'
    }));

    function showNextImage() {
        _setImageIndex(index => {
            if (index === props.designs.length - 1) return 0
            return index + 1
        })
    }

    function showPrevImage() {
        _setImageIndex(index => {
            if (index === 0) return props.designs.length - 1
            return index - 1
        })
    }

    const setImageIndex = (imageIndex) => {
        sessionStorage.setItem("scrollPosition", String(imageIndex * 185));
        _setImageIndex(imageIndex);
    };

    const saveScrollPosition = () => {
        // console.log(imageList.current.pageYOffset)
        // sessionStorage.setItem("scrollPosition", String(imageList.current.pageYOffset));
    }

    // handle scroll position after content load


    useEffect(() => {
        console.log("Loaded")
        console.log(imageList.current?.scrollTop)
        handleScrollPosition();
    });

    const handleScrollPosition = () => {
        const scrollPosition = sessionStorage.getItem("scrollPosition");
        if (scrollPosition && imageList) {
            console.log("Before");
             console.log(imageList.current?.scrollTop)
             // imageList?.current?.scrollTop = 400 // (parseInt(scrollPosition));
            // imageList.current?scrollTo(0, parseInt(scrollPosition));

            imageList?.current?.scrollTo(0, parseInt(scrollPosition));

            // document.getElementById("ANDD").scrollTop = Integer(scrollPosition)
            sessionStorage.removeItem("scrollPosition");
            console.log("After");
            console.log(imageList.current?.scrollTop)
        }

        // document.getElementById("R10773661").offsetTop
    };

    const imageList = useRef<HTMLUListElement>(null)
    // const executeScroll = () => myRef.current.scrollIntoView()

    handleScrollPosition();


    type Design = {
        id: string; // "R10773
        src: string;
        srcThumb: string; // 
        srcMedium: string;
    };
    
    function findObjectByPropertyValue(objects: Array<Design>, propertyName: keyof Design, propertyValue: any): number {
        return objects.findIndex(obj => obj[propertyName] === propertyValue);
    }

/*
    const myRefs= useRef([]);

    const executeScroll = (ref) => ref.current.scrollIntoView()

    handleClick = e => {
        sessionStorage.setItem("scrollPosition", window.pageYOffset);
    };
    */

    function ThumbnailList(){
        return(
        <>
            <Button
                onClick={showPrevImage}
                className="img-slider-btn"
                style={{ alignItems: 'centre', top: 0 }}
                aria-label="View Previous Image"
            >
                <ExpandLessIcon aria-hidden />
            </Button>
            <Button
                onClick={showNextImage}
                className="img-slider-btn"
                style={{ bottom: 0 }}
                aria-label="View Next Image"
            >
                <ExpandMoreIcon aria-hidden />
            </Button>
            <ImageList
                sx={{ height: 600 }}
                cols={1}
                ref={imageList}

            >

            {props.designs.map((image, index) => (
                    <Button
                        key={image.key}
                        className="img-slider-dot-btn"
                        aria-label={`View Image ${image.id}`}
                        onClick={() => setImageIndex(index)}
                        // ref={(el) => (myRefs.current[index] = el)}
                    >
                        <ImageListItem key={image.id}  id={image.id}>
                            <img
                                style={{
                                    width: "150px",
                                    border: `${imageIndex === index ? "3px solid #555" : ""}`,
                                    // transform: "translate(0,`${-150 * imageIndex}px`)",
                                }}
                                src={`${image.srcMedium}`}
                                height={100}
                                width={100}
                                loading="lazy"

                            />
                        </ImageListItem>
                    </Button>
                ))}
            </ImageList>
{/*
            </Box>
*/}

{/*
                <ImageList sx={{ height: 600 }} cols={1}>
                    {props.designs.map((image, index) => (
                        <Button
                            key={image.key}
                            className="img-slider-dot-btn"
                            aria-label={`View Image ${image.id}`}
                            onClick={() => setImageIndex(index)}
                        >
                            <ImageListItem key={image.id}>
                                <img
                                    // srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                                    src={`${image.srcMedium}`}
                                    // alt={item.title}
                                    height={100}
                                    width={100}
                                    loading="lazy"
                                    
                                />
                            </ImageListItem>
                        </Button>
                    ))}
                 </ImageList>
                
                */}
            {/* </Grid> */}
{/*        </div> */}
        </>
        )
    }
    
    function MainImage(){
        
        return(
                <img
                    key={imageIndex}
                    //  src={findObjectByPropertyValue(props.designs, "id", imageIndex).src}
                    src={props.designs[imageIndex].src}
                    // height={400}
                    // width={"100pc"}
                    // aria-hidden={imageIndex !== index}
                    // className="img-slider-img"
                    /* style={{ translate: `${-100 * imageIndex}%`, */
                    style={{
                        // objectFit: "cover",
                        maxWidth: "400px",
                        // maxHeight: "600px",
                        // flexShrink: 0,
                        // flexGrow: 0
                    }}

                />
        )
    }
    function ImageV() {
        return (
            <Grid container spacing={0}>
                <Grid item xs={6}>
                    <Item sx={{borderRight: 0, borderBottom: 0}}>Representations of {props.id}</Item>
                </Grid>
                <Grid item xs={6}>
                    <Item sx={{textAlign: 'right', borderBottom: 0, borderLeft: 0}}>Result 1 of {props.designs.length}</Item>
                </Grid>
                <Grid item xs={2}>
                     <Item sx={{textAlign: 'center', borderRight: 0, borderBottom: 0, maxHeight: "300px",}}>
                        <ThumbnailList/>
                    </Item>
                </Grid>
                <Grid item xs={10} sx={{alignItems:"center", alignContent:"center", textAlign: "center"}}>
                    <Item sx={{textAlign: 'center'}}>
                        <MainImage/>
                    </Item>
                </Grid>
            </Grid>
        )
    }

    return (
        <StyledYourOrgYourComponentLibPocImageViewerWrapper>
            {/* <ImageV/> */}
            <Button onClick={handleOpen} className="MuiModal-root">Open gallery</Button>
            <Dialog onClose={handleClose} open={open} maxWidth='lg' fullWidth>
                <ImageV/>
            </Dialog>
        </StyledYourOrgYourComponentLibPocImageViewerWrapper>
    );
};
