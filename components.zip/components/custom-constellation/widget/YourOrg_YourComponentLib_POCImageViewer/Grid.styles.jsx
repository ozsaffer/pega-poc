import styled, { css } from 'styled-components';
import { calculateFontSize, defaultThemeProp } from '@pega/cosmos-react-core';
export const StyledGridContainer = styled.div(({ fitContent, height, theme }) => {
    return css `
      border: calc(0.5 * ${theme.base.spacing}) solid ${theme.base.colors.black};
      background-color: ${theme.base.colors.blue.light};

      ${height &&
    css `
        height: ${height}rem;
      `}

      ${fitContent &&
    css `
        width: fit-content;
      `}
    `;
});
StyledGridContainer.defaultProps = defaultThemeProp;
export const StyledGridItem = styled.div(({ theme }) => {
    const fontSize = calculateFontSize(theme.base['font-size'], theme.base['font-scale']);
    return css `
    border: calc(0.5 * ${theme.base.spacing}) solid ${theme.base.colors.black};
    padding: ${theme.base.spacing};
    text-align: center;
    background-color: ${theme.base.colors.orange.light};
    color: ${theme.base.colors.black};

    span {
      font-size: ${fontSize.xl};
      font-weight: ${theme.base['font-weight'].bold};
    }
  `;
});
StyledGridItem.defaultProps = defaultThemeProp;

