import { useMemo, Children } from 'react';
import PropTypes from 'prop-types';
import {Button, Modal, OneColumnPage as OneColumn} from '@pega/cosmos-react-core';
import { ConfigurableLayout } from '@pega/cosmos-react-work'
// import { registerIcon } from '@pega/cosmos-react-core';

// temp
// import * as headlineIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/headline.icon';

import StyledYourOrgYourComponentLibPocImageViewerWrapper from './styles';

import GetNextWork from './GetNextWork.jsx';
import { getLayoutDataFromRegion } from './utils';
import Typography from "@material-ui/core/Typography";
import {Box} from "@material-ui/core";

// temp
// registerIcon(headlineIcon);

// currently getting 'icon' from props is not supported with iconRegistry
// have to manually get icon, so can't determine a runtime for now
// so "headline" icon is hardcoded.



// Duplicated runtime code from Constellation Design System Component

// props passed in combination of props from property panel (config.json) and run time props from Constellation
// any default values in config.pros should be set in defaultProps at bottom of this file
export default function YourOrgYourComponentLibPocImageViewer(props) {

  // add back in icon when working
  // const { children, title, icon, useConfigurableLayout, getPConnect, enableGetNextWork } = props;
  const { children, title, useConfigurableLayout, getPConnect, enableGetNextWork } = props;
  const childArray = useMemo(() => {
    return Children.toArray(children);
  }, [children]);
  const layoutItemsA = useMemo(() => {
    return getLayoutDataFromRegion(childArray[0]);
  }, [childArray[0]]);

  // temp
  const tempIcon = "pi pi-headline";

  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (

    <StyledYourOrgYourComponentLibPocImageViewerWrapper>
    <h1>Test  </h1>
      <Button onClick={handleOpen}>Open modal</Button>
      <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Text in a modal
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            Duis mollis, est non commodo luctus, nisi erat porttitor ligula.
          </Typography>
        </Box>
      </Modal>
    </StyledYourOrgYourComponentLibPocImageViewerWrapper>

  );



}

YourOrgYourComponentLibPocImageViewer.defaultProps = {
  /* icon: '', */
  useConfigurableLayout: false
};

YourOrgYourComponentLibPocImageViewer.propTypes = {
  children: PropTypes.arrayOf(PropTypes.node).isRequired,
  title: PropTypes.string.isRequired,
  /* icon: PropTypes.string, */
  useConfigurableLayout: PropTypes.bool
};
