
import React from "react";
import type { PConnProps } from '@pega/react-sdk-components/lib/types/PConnProps';


import OneColumn from './OneColumn';

import StyledYourOrgYourComponentLibPocImageViewerWrapper from './styles';

interface YourOrgYourComponentLibPocImageViewerProps extends PConnProps {
  // If any, enter additional props that only exist on this componentName
  children: Array<any>
}



// Duplicated runtime code from React SDK

// props passed in combination of props from property panel (config.json) and run time props from Constellation
// any default values in config.pros should be set in defaultProps at bottom of this file
export default function YourOrgYourComponentLibPocImageViewer(props: YourOrgYourComponentLibPocImageViewerProps) {

    return (
      <StyledYourOrgYourComponentLibPocImageViewerWrapper>
      <OneColumn
       {...props}
      />
      </StyledYourOrgYourComponentLibPocImageViewerWrapper>
  );

}
