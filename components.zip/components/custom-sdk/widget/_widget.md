# The **custom-sdk/widget** directory

The **src/components/custom-sdk/widget** directory contains the code for the custom **widget** components you want to create and use with the **React SDK**.

When you run the **npm run  create** command to create new _widget_ components, the generated code that you can use as a starting point for your component
development will be placed in component-specific folders in **src/components/custom-sdk/widget**.
